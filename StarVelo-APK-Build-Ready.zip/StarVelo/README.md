# Star Velo (Android prototype)

A native Android speed-test prototype with a Compose UI, download/upload measurements, latency/jitter sampling, connection-type detection, and public-IP ISP lookup.

## Important limitations

- The initial free test endpoint is Cloudflare's public speed-test endpoint (`speed.cloudflare.com`). It is a global edge service and does **not** guarantee that a test is served from mainland China.
- ISP information comes from the public IP lookup (`ipwho.is`). VPNs, proxies, enterprise gateways, and carrier NAT can affect the reported ISP/city.
- The current speed calculation uses the configured test payload size divided by elapsed transfer time. For a production-grade measurement, read and count actual transferred bytes, run multiple payload sizes, repeat tests, and add calibrated regional servers.
- This project does not include an APK binary. Build it with Android Studio on a machine with Android SDK Platform 35 and JDK 17.

## Build APK

1. Open this folder in Android Studio.
2. Allow Gradle sync to complete.
3. Select **Build > Build APK(s)**.
4. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Next step for reliable mainland China server labels

Deploy or contract test endpoints in mainland China (with appropriate hosting and regulatory compliance), and configure each endpoint with a verified display name, city, operator, and URL. Do not label a server as China Mobile/Unicom/Telecom unless the endpoint's network/operator has been verified.


## 自动生成 APK（无需本地安装 Android Studio）

1. 将本 ZIP 解压。
2. 在 GitHub 新建一个空仓库，并把解压后的 `StarVelo` 文件夹中的全部内容上传到仓库根目录（确保 `.github/workflows/build-apk.yml` 也上传）。
3. 打开仓库的 **Actions** 页面，选择 **Build StarVelo APK**，点击 **Run workflow**。
4. 等待构建完成，在该次运行页面底部的 **Artifacts** 下载 `StarVelo-debug-apk`。
5. 解压下载的文件，即可得到 `app-debug.apk`，传到 Android 手机上安装。

说明：这是用于测试安装的 debug APK，不是发布用的正式签名版本。首次运行 GitHub Actions 需要 GitHub 账号，并确保仓库允许 Actions。
