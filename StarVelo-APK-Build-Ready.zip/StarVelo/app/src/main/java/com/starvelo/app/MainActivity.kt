package com.starvelo.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF101F30)
private val Cyan = Color(0xFF54D6FF)
private val Muted = Color(0xFF91A7BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, background = Navy, surface = Panel,
                onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
            )) {
                StarVeloScreen(this)
            }
        }
    }
}

private data class TestResult(
    val pingMs: Long? = null,
    val jitterMs: Long? = null,
    val downloadMbps: Double? = null,
    val uploadMbps: Double? = null,
    val isp: String = "尚未检测",
    val city: String = "",
    val network: String = "检测中",
    val server: String = "Cloudflare 全球边缘节点",
    val note: String = ""
)

@androidx.compose.runtime.Composable
private fun StarVeloScreen(context: Context) {
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("准备就绪") }
    var result by remember { mutableStateOf(TestResult(network = networkType(context))) }

    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.size(54.dp).background(Color(0xFF173B54), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("✦", color = Cyan, fontSize = 32.sp, fontWeight = FontWeight.Bold) }
                Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                    Text("Star Velo", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("NETWORK SPEED TEST", fontSize = 11.sp, color = Muted, letterSpacing = 1.5.sp)
                }
                Text("BETA", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MetricCard("下载速度", result.downloadMbps?.let { fmt(it) } ?: "--", "Mbps", Modifier.weight(1f))
                MetricCard("上传速度", result.uploadMbps?.let { fmt(it) } ?: "--", "Mbps", Modifier.weight(1f))
                MetricCard("延迟", result.pingMs?.toString() ?: "--", "ms", Modifier.weight(1f))
            }
            Spacer(Modifier.height(30.dp))
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(164.dp)) {
                if (running) CircularProgressIndicator(modifier = Modifier.fillMaxSize(), color = Cyan, strokeWidth = 4.dp)
                Box(
                    modifier = Modifier.size(132.dp).background(Color(0xFF102638), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (running) "TEST" else "GO", color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text(if (running) "测速中" else "开始测速", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(status, color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    if (!running) {
                        running = true
                        status = "正在检测网络与运营商…"
                        scope.launch {
                            result = withContext(Dispatchers.IO) {
                                SpeedTest.run(context) { message -> status = message }
                            }
                            status = if (result.note.isBlank()) "测速完成" else result.note
                            running = false
                        }
                    }
                },
                enabled = !running,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(if (running) "正在测速…" else "开始测速", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(24.dp))
            InfoCard("网络信息", listOf(
                "连接类型" to result.network,
                "运营商 / ISP" to result.isp,
                "IP 定位城市" to result.city.ifBlank { "未获取" },
                "测速节点" to result.server,
                "抖动" to (result.jitterMs?.let { "$it ms" } ?: "--")
            ))
            Spacer(Modifier.height(14.dp))
            Text(
                "精度提示：测速结果取决于当前网络、设备和服务器负载。当前免费测试端点为 Cloudflare 全球边缘节点，不保证落在中国大陆；ISP 名称依据公网 IP 查询，VPN/代理可能影响识别。",
                color = Muted, fontSize = 11.sp, lineHeight = 16.sp
            )
        }
    }
}

@androidx.compose.runtime.Composable
private fun MetricCard(title: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.padding(vertical = 14.dp, horizontal = 10.dp), horizontalAlignment = Alignment.Start) {
            Text(title, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(7.dp))
            Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(unit, color = Cyan, fontSize = 11.sp)
        }
    }
}

@androidx.compose.runtime.Composable
private fun InfoCard(title: String, rows: List<Pair<String, String>>) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(10.dp))
            rows.forEachIndexed { index, pair ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                    Text(pair.first, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(0.9f))
                    Text(pair.second, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1.4f))
                }
                if (index != rows.lastIndex) Spacer(Modifier.height(1.dp))
            }
        }
    }
}

private fun networkType(context: Context): String {
    return try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "无网络连接"
        val caps = cm.getNetworkCapabilities(network) ?: return "未知网络"
        when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "手机流量"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "以太网"
            else -> "其他网络"
        }
    } catch (_: Exception) { "未知网络" }
}

private object SpeedTest {
    private const val BASE = "https://speed.cloudflare.com"
    private const val IP_INFO = "https://ipwho.is/"

    fun run(context: Context, onStatus: (String) -> Unit): TestResult {
        val initial = TestResult(network = networkType(context))
        return try {
            onStatus("正在查询公网 IP 与运营商…")
            val info = getJson(IP_INFO)
            val connection = info.optJSONObject("connection") ?: JSONObject()
            val isp = connection.optString("isp", "").ifBlank {
                connection.optString("org", "").ifBlank { "未能识别" }
            }
            val city = info.optString("city", "")
            onStatus("正在测量延迟与抖动…")
            val pings = mutableListOf<Long>()
            repeat(5) {
                val start = System.nanoTime()
                request("$BASE/__down?bytes=0", "GET", null) { input ->
                    val buffer = ByteArray(1024)
                    while (input.read(buffer) != -1) { /* drain response */ }
                }
                pings += ((System.nanoTime() - start) / 1_000_000L)
            }
            val sorted = pings.sorted()
            val ping = sorted[sorted.size / 2]
            val jitter = if (pings.size > 1) {
                (pings.zipWithNext { a, b -> kotlin.math.abs(a - b) }.average()).roundToInt().toLong()
            } else 0L

            onStatus("正在测试下载速度…")
            val requestedDownloadBytes = 12_000_000L
            val downloadStart = System.nanoTime()
            var downloadedBytes = 0L
            request("$BASE/__down?bytes=$requestedDownloadBytes", "GET", null) { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    downloadedBytes += count
                }
            }
            val downloadSeconds = ((System.nanoTime() - downloadStart) / 1_000_000_000.0).coerceAtLeast(0.001)
            if (downloadedBytes == 0L) throw IllegalStateException("下载测试未收到数据")
            val downloadMbps = downloadedBytes * 8.0 / downloadSeconds / 1_000_000.0

            onStatus("正在测试上传速度…")
            val uploadBytes = ByteArray(2_000_000)
            java.security.SecureRandom().nextBytes(uploadBytes)
            val uploadStart = System.nanoTime()
            request("$BASE/__up", "POST", uploadBytes) { input ->
                val buffer = ByteArray(4096)
                while (input.read(buffer) != -1) { /* drain response */ }
            }
            val uploadSeconds = ((System.nanoTime() - uploadStart) / 1_000_000_000.0).coerceAtLeast(0.001)
            val uploadMbps = uploadBytes.size * 8.0 / uploadSeconds / 1_000_000.0

            initial.copy(
                pingMs = ping, jitterMs = jitter,
                downloadMbps = downloadMbps, uploadMbps = uploadMbps,
                isp = isp, city = city,
                server = "Cloudflare 全球边缘节点",
                note = "测速完成（建议重复测试取平均值）"
            )
        } catch (e: Exception) {
            initial.copy(note = "测速失败：${e.localizedMessage ?: "网络连接失败"}。请检查网络后重试。")
        }
    }

    private fun measureSeconds(block: () -> Unit): Double {
        val start = System.nanoTime()
        block()
        return ((System.nanoTime() - start) / 1_000_000_000.0).coerceAtLeast(0.001)
    }

    private fun getJson(url: String): JSONObject {
        var result = JSONObject()
        request(url, "GET", null) { input -> result = JSONObject(input.bufferedReader().use { it.readText() }) }
        if (result.optBoolean("success", true).not() || result.optString("success") == "false") {
            throw IllegalStateException("公网 IP 信息查询失败")
        }
        return result
    }

    private fun request(urlString: String, method: String, body: ByteArray?, consume: (java.io.InputStream) -> Unit) {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 10_000
            readTimeout = 30_000
            useCaches = false
            setRequestProperty("User-Agent", "StarVelo/0.1 Android")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/octet-stream")
                setFixedLengthStreamingMode(body.size)
            }
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                ?: throw IllegalStateException("服务器返回 HTTP $code")
            BufferedInputStream(stream).use(consume)
            if (code !in 200..299) throw IllegalStateException("服务器返回 HTTP $code")
        } finally {
            connection.disconnect()
        }
    }
}

private fun fmt(value: Double): String = when {
    value >= 1000 -> String.format("%.0f", value)
    value >= 100 -> String.format("%.1f", value)
    else -> String.format("%.2f", value)
}
